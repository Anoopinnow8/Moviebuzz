import React from "react";
import "./style.scss";

function Explore() {
  return <div>Explore</div>;
}

export default Explore;
