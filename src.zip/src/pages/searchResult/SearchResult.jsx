import React from "react";
import "./style.scss";

function SearchResult() {
  return <div>SearchResult</div>;
}

export default SearchResult;
