import React from "react";
import "./style.scss";

function Details() {
  return <div>Details</div>;
}

export default Details;
