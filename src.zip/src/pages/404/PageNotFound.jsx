import React from "react";
import "./style.scss";
function PageNotFound() {
  return <div>PageNotFound</div>;
}

export default PageNotFound;
