import React, { useState } from "react";
import "./style.scss";
import { useNavigate } from "react-router-dom";
import useFetch from "../../../hooks/useFetch";

const HeroBanner = () => {
  const [background, setBackground] = useState("");
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const { data, loading } = useFetch("/movie/upcoming");
  console.log(data, "hgugugug");
  const searchQueryHandler = (event) => {
    event.preventDefault();
    if (query.length > 0) {
      console.log(event.key, "ggugu");
      navigate(`/search/${query}`);
    }
  };

  return (
    <div className="hero-banner">
      <div className="wrapper">
        <div className="heroBannerContent">
          <span className="title">Welcome</span>
          <span className="subTitle">
            Welcome Discover the millions of movies,shows
          </span>
          <div className="searchInput">
            <form onSubmit={(e) => searchQueryHandler(e)}>
              <input
                type="text"
                placeholder="Search Your Movie"
                onChange={(e) => setQuery(e.target.value)}
              />

              <button>Search </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;
