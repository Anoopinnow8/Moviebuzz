import React from "react";
import "./style.scss";

function Header() {
  return <div>hfnvrthbgv Header</div>;
}

export default Header;
